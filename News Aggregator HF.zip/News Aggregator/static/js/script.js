function searchNews() {
    const query = document.getElementById('searchQuery').value.trim();
    const newsContainer = document.getElementById('newsContainer');

    if (!query) {
        alert("Please enter a search term!");
        return;
    }

    // Show loading message
    newsContainer.innerHTML = '<p>Loading...</p>';

    fetch('/search', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `query=${encodeURIComponent(query)}`,
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        newsContainer.innerHTML = '';

        if (data.error) {
            newsContainer.innerHTML = `<p>Error: ${data.error}</p>`;
            return;
        }

        if (data.length === 0) {
            newsContainer.innerHTML = '<p>No articles found. Try a different search term.</p>';
            return;
        }

        data.forEach(article => {
            const articleElement = document.createElement('article');
            articleElement.innerHTML = `
                <h2>${article.title}</h2>
                <p>${article.description || 'No description available.'}</p>
                <a href="${article.url}" target="_blank">Read More</a>
            `;
            newsContainer.appendChild(articleElement);
        });

        // Add Search Again Button
        const searchAgainBtn = document.createElement('button');
        searchAgainBtn.textContent = 'Search Again';
        searchAgainBtn.style.marginTop = '20px';
        searchAgainBtn.onclick = clearSearch;
        newsContainer.appendChild(searchAgainBtn);
    })
    .catch(error => {
        console.error('Error fetching news:', error);
        newsContainer.innerHTML = `<p>Error fetching news. Please try again later.</p>`;
    });
}

// Function to clear search and reset the page
function clearSearch() {
    document.getElementById('searchQuery').value = '';
    document.getElementById('newsContainer').innerHTML = '';
}
