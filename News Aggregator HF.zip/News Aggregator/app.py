from flask import Flask, render_template, request, jsonify
import requests

app = Flask(__name__)
NEWS_API_KEY = '0f6465f6433e41c4a176cba372570284'  
NEWS_API_URL = 'https://newsapi.org/v2/everything'

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/search', methods=['POST'])
def search():
    query = request.form.get('query')
    if not query:
        return jsonify({"error": "No query provided"}), 400

    response = requests.get(NEWS_API_URL, params={'q': query, 'apiKey': NEWS_API_KEY})
    data = response.json()
    
    if response.status_code != 200 or 'articles' not in data:
        return jsonify({"error": "Failed to fetch news"}), 500
    
    return jsonify(data['articles'])

if __name__ == '__main__':
    app.run(debug=True)
